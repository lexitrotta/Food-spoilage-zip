# silver_mendeley_survival.py
"""
Create SILVER layer for Mendeley Shelf-Life data (survival-ready).

"""

import pandas as pd
from pathlib import Path

# --- Config ---
BRONZE_PATH = Path("out/bronze/Mendeley_SensorFeed_bronze.csv")
SILVER_DIR = Path("out/silver")
SILVER_PATH = SILVER_DIR / "mendeley_survival_silver.csv"

# Spoilage threshold in minutes (observations at or above are considered spoiled)
THRESHOLD_MINUTES = 4000  # adjust if you change your definition in the paper


def main():
    if not BRONZE_PATH.exists():
        raise FileNotFoundError(f"Bronze file not found: {BRONZE_PATH}")

    # 1. Load BRONZE data (raw structure: e.g., Time, Temp, and any other original fields)
    df = pd.read_csv(BRONZE_PATH)

    # Basic sanity check for expected columns
    expected_cols = {"Time", "Temp"}
    missing = expected_cols - set(df.columns)
    if missing:
        raise ValueError(f"Expected columns missing from bronze data: {missing}")

    # 2. Create survival targets
    # duration = elapsed time in minutes (Harrison et al., 2015)
    df["duration"] = df["Time"].astype(float)

    # event = 1 if spoiled (duration >= threshold), else 0 (right-censored)
    df["event"] = (df["duration"] >= THRESHOLD_MINUTES).astype(int)

    # 3. Reduce to essential modeling features (drop unnecessary columns)
    silver = df[["duration", "event", "Temp"]].copy()

    # 4. Save SILVER dataset
    SILVER_DIR.mkdir(parents=True, exist_ok=True)
    silver.to_csv(SILVER_PATH, index=False)

    # 5. Quick console summary
    print("=== SILVER SURVIVAL DATASET CREATED ===")
    print(f"Source (bronze): {BRONZE_PATH.resolve()}")
    print(f"Silver output   : {SILVER_PATH.resolve()}\n")

    print("Head:")
    print(silver.head(), "\n")

    print("Event value counts (0 = censored, 1 = spoiled):")
    print(silver["event"].value_counts())


if __name__ == "__main__":
    main()
