# gold_mendeley_survival.py
"""
Create GOLD layer for Mendeley Shelf-Life data (survival-ready).

"""

import pandas as pd
from sklearn.preprocessing import StandardScaler
from pathlib import Path

# Load SILVER survival dataset
silver = pd.read_csv("out/silver/mendeley_survival_silver.csv")

# Separate targets and features
y_duration = silver["duration"].astype(float)
y_event = silver["event"].astype(int)
X = silver.drop(columns=["duration", "event"])

# Identify numeric vs categorical (right now Temp is numeric)
num_cols = X.select_dtypes(include=["number"]).columns.tolist()
cat_cols = [c for c in X.columns if c not in num_cols]

# 1. Scale numeric predictors
if num_cols:
    scaler = StandardScaler()
    X[num_cols] = scaler.fit_transform(X[num_cols])

# 2. One-hot encode categoricals (if you later add product type, storage method, etc.)
if cat_cols:
    X = pd.get_dummies(X, columns=cat_cols, dummy_na=True)

# 3. Reassemble Gold dataset
gold = pd.concat(
    [
        y_duration.rename("duration"),
        y_event.rename("event"),
        X
    ],
    axis=1
)

# 4. Drop any zero-variance columns
nunique = gold.nunique(dropna=False)
keep_cols = nunique[nunique > 1].index
gold = gold[keep_cols]

# 5. Save as GOLD survival dataset
Path("out/gold").mkdir(parents=True, exist_ok=True)
gold.to_csv("out/gold/gold_survival.csv", index=False)

print("Gold survival shape:", gold.shape)
print(gold.head())
