# survival_pipeline.py
# Time-to-event modeling with CoxPH (lifelines): stratified split, random search + 10-fold CV

import argparse
from pathlib import Path
import numpy as np
import pandas as pd
from sklearn.model_selection import StratifiedShuffleSplit, StratifiedKFold
from sklearn.utils import check_random_state
from lifelines import CoxPHFitter
from lifelines.utils import concordance_index
import joblib
import warnings

warnings.filterwarnings("ignore", category=UserWarning)

# -----------------------
# Utilities
# -----------------------
def load_and_prepare(csv_path: Path):
    df = pd.read_csv(csv_path)
    # Ensure required columns exist
    if not {"duration", "event"}.issubset(df.columns):
        raise ValueError("Input must contain 'duration' and 'event' columns.")

    # Separate features/targets
    y_duration = df["duration"].astype(float)
    y_event = df["event"].astype(int)

    # One-hot encode categoricals; keep numeric as-is
    X = df.drop(columns=["duration", "event"]).copy()
    cat_cols = X.select_dtypes(exclude=np.number).columns.tolist()
    if cat_cols:
        X = pd.get_dummies(X, columns=cat_cols, dummy_na=True)

    # Merge back (lifelines expects a single DataFrame with both y and X)
    full = pd.concat([y_duration.rename("duration"), y_event.rename("event"), X], axis=1)

    # Drop columns with zero variance (lifelines can choke on singular matrices)
    nunique = full.nunique(dropna=False)
    keep_cols = nunique[nunique > 1].index
    full = full[keep_cols]

    return full


def stratified_train_val_test(df, test_size=0.2, val_size=0.2, random_state=42):
    """
    Stratify by 'event' proportion. First split off test, then split train into train/val.
    Default 60/20/20 when test_size=0.2, val_size=0.25 of remaining (i.e., 0.2 of all).
    """
    rng = check_random_state(random_state)
    y = df["event"]

    # First: train_val vs test
    sss1 = StratifiedShuffleSplit(n_splits=1, test_size=test_size, random_state=random_state)
    idx_all = np.arange(len(df))
    trv_idx, te_idx = next(sss1.split(idx_all, y))

    df_trv = df.iloc[trv_idx].reset_index(drop=True)
    df_te = df.iloc[te_idx].reset_index(drop=True)

    # Second: train vs val (val_size fraction of whole dataset => adjust to remaining)
    # If we want 60/20/20: test_size = 0.2, val_size = 0.25 of remaining (0.2 overall).
    sss2 = StratifiedShuffleSplit(n_splits=1, test_size=val_size, random_state=random_state)
    y_trv = df_trv["event"]
    tr_idx, va_idx = next(sss2.split(np.arange(len(df_trv)), y_trv))

    df_tr = df_trv.iloc[tr_idx].reset_index(drop=True)
    df_va = df_trv.iloc[va_idx].reset_index(drop=True)

    return df_tr, df_va, df_te


def cv_score_coxph(df, penalizer, l1_ratio, n_folds=10, random_state=42):
    """
    10-fold CV for given hyperparameters.
    Returns: (mean_cindex, mean_mae_uncensored)
    """
    y_event = df["event"].astype(int).values
    skf = StratifiedKFold(n_splits=n_folds, shuffle=True, random_state=random_state)

    cindex_scores = []
    mae_scores = []

    for tr_idx, va_idx in skf.split(np.arange(len(df)), y_event):
        train = df.iloc[tr_idx].copy()
        valid = df.iloc[va_idx].copy()

        cph = CoxPHFitter(penalizer=penalizer, l1_ratio=l1_ratio)
        cph.fit(train, duration_col="duration", event_col="event")

        # C-index on validation (uses durations + events)
        ci = concordance_index(
            valid["duration"], 
            -cph.predict_partial_hazard(valid),  # negative: higher risk => lower predicted time
            event_observed=valid["event"]
        )
        cindex_scores.append(ci)

        # MAE on uncensored only (event==1), comparing observed duration vs predicted median survival time
        valid_obs = valid[valid["event"] == 1]
        if len(valid_obs) > 0:
            try:
                pred_median = cph.predict_median(valid_obs)
                mae = np.mean(np.abs(valid_obs["duration"].values - pred_median.values))
            except Exception:
                mae = np.nan
        else:
            mae = np.nan
        mae_scores.append(mae)

    # Replace NaNs in MAE with large penalty so models that fail to produce medians don't "win"
    mae_scores = [m if pd.notna(m) else 1e9 for m in mae_scores]

    return float(np.mean(cindex_scores)), float(np.mean(mae_scores))


def random_search_coxph(df, n_iter=25, n_folds=10, random_state=42,
                        penalizer_range=(1e-5, 1.0), l1_choices=(0.0, 0.1, 0.3, 0.5, 0.7, 1.0)):
    """
    Random search over penalizer (log-uniform) and l1_ratio (choice set).
    """
    rng = check_random_state(random_state)
    trials = []

    for i in range(n_iter):
        # sample penalizer ~ log-uniform
        lp = np.log10(penalizer_range[0]); hp = np.log10(penalizer_range[1])
        penalizer = 10 ** rng.uniform(lp, hp)
        l1_ratio = rng.choice(l1_choices)

        ci, mae = cv_score_coxph(df, penalizer=penalizer, l1_ratio=l1_ratio,
                                 n_folds=n_folds, random_state=random_state)
        trials.append({"penalizer": penalizer, "l1_ratio": float(l1_ratio),
                       "cv_cindex": ci, "cv_mae": mae})

    trials_df = pd.DataFrame(trials)
    # Select best: maximize c-index, then minimize MAE (tie-breaker)
    trials_df = trials_df.sort_values(["cv_cindex", "cv_mae"], ascending=[False, True]).reset_index(drop=True)
    best = trials_df.iloc[0].to_dict()
    return best, trials_df


def fit_evaluate_save(train_df, val_df, test_df, best_params, out_dir: Path):
    out_dir.mkdir(parents=True, exist_ok=True)
    report_dir = out_dir / "reports"
    model_dir = out_dir / "models"
    report_dir.mkdir(parents=True, exist_ok=True)
    model_dir.mkdir(parents=True, exist_ok=True)

    # Refit on train+val with best hyperparameters
    tv_df = pd.concat([train_df, val_df], ignore_index=True)
    cph = CoxPHFitter(penalizer=best_params["penalizer"], l1_ratio=best_params["l1_ratio"])
    cph.fit(tv_df, duration_col="duration", event_col="event")

    # PRINT SUMMARY
    print("\n=== COX MODEL SUMMARY ===")
    print(cph.summary)

    # Evaluate on test
    test_ci = concordance_index(
        test_df["duration"],
        -cph.predict_partial_hazard(test_df),
        event_observed=test_df["event"]
    )

    test_obs = test_df[test_df["event"] == 1]
    if len(test_obs) > 0:
        pred_median = cph.predict_median(test_obs)
        test_mae = float(np.mean(np.abs(test_obs["duration"].values - pred_median.values)))
    else:
        test_mae = np.nan

    # Save artifacts
    coef_path = report_dir / "coxph_coefficients.csv"
    cph.summary.to_csv(coef_path, index=False)

    model_path = model_dir / "coxph_model.pkl"
    joblib.dump(cph, model_path)

    metrics = {
        "best_penalizer": best_params["penalizer"],
        "best_l1_ratio": best_params["l1_ratio"],
        "cv_cindex": best_params["cv_cindex"],
        "cv_mae": best_params["cv_mae"],
        "test_cindex": test_ci,
        "test_mae_uncensored": test_mae
    }
    pd.Series(metrics).to_csv(report_dir / "survival_metrics.csv")

    print("\n=== BEST (CV) ===")
    print(f"C-index: {best_params['cv_cindex']:.4f} | MAE (uncensored): {best_params['cv_mae']:.4f}")
    print("\n=== TEST ===")
    print(f"C-index: {test_ci:.4f} | MAE (uncensored): {test_mae:.4f}")
    print("\nSaved:")
    print(f"  Coefficients -> {coef_path}")
    print(f"  Model -> {model_path}")
    print(f"  Metrics -> {report_dir / 'survival_metrics.csv'}")


# -----------------------
# Main
# -----------------------
def main():
    p = argparse.ArgumentParser(description="Time-to-event modeling with CoxPH (Random Search + 10-fold CV)")
    p.add_argument("--data", type=str, default="out/gold/gold_survival.csv",
                   help="Path to survival dataset CSV with columns: duration, event, and features.")
    p.add_argument("--test_size", type=float, default=0.20, help="Hold-out test fraction (default 0.20).")
    p.add_argument("--val_size", type=float, default=0.25,
                   help="Validation fraction of TRAIN_VAL (0.25 => overall 0.20 when test=0.20).")
    p.add_argument("--cv_folds", type=int, default=10, help="Folds for CV inside Random Search (default 10).")
    p.add_argument("--n_iter", type=int, default=25, help="Random search iterations (default 25).")
    p.add_argument("--seed", type=int, default=42, help="Random seed.")
    p.add_argument("--out", type=str, default="out/survival",
                   help="Output directory for reports/models.")
    args = p.parse_args()

    data_path = Path(args.data)
    out_dir = Path(args.out)

    print("[Load] ", data_path)
    full = load_and_prepare(data_path)

    # Three-way split (stratified on event)
    print("[Split] Stratified train/val/test")
    train_df, val_df, test_df = stratified_train_val_test(
        full, test_size=args.test_size, val_size=args.val_size, random_state=args.seed
    )
    print(f"  Train: {len(train_df)} | Val: {len(val_df)} | Test: {len(test_df)}")
    print(f"  Event rate (train/val/test): "
          f"{train_df['event'].mean():.3f} / {val_df['event'].mean():.3f} / {test_df['event'].mean():.3f}")

    # Random search + 10-fold CV on the TRAIN split only (avoid leakage)
    print("[Tune] Random search with 10-fold CV (CoxPH: penalizer, l1_ratio)")
    best_params, trials = random_search_coxph(
        train_df, n_iter=args.n_iter, n_folds=args.cv_folds, random_state=args.seed
    )

    # Save tuning table
    out_dir.mkdir(parents=True, exist_ok=True)
    trials.to_csv(out_dir / "random_search_trials.csv", index=False)

    # Refit on train+val, evaluate on test, save artifacts
    fit_evaluate_save(train_df, val_df, test_df, best_params, out_dir)


if __name__ == "__main__":
    main()
