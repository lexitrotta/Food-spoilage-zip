# =========================================
# DAAN 888 Full Pipeline Runner
# Bronze → Silver → Gold → Survival
# =========================================

# Use python or py depending on system

$pythonExe = "py"

# Project root = folder containing this script
$projectRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $projectRoot

Write-Host "=== STARTING FOOD SPOILAGE PIPELINE ==="
Write-Host "Project root: $projectRoot"

# -------------------------
# 1. BRONZE
# -------------------------
Write-Host "`n[1/4] BRONZE: Copy raw → bronze..."
& $pythonExe ".\scripts\bronze_mendeley.py"

# -------------------------
# 2. SILVER
# -------------------------
Write-Host "`n[2/4] SILVER: Create survival-ready dataset..."
& $pythonExe ".\scripts\silver_mendeley_survival.py"

# -------------------------
# 3. GOLD
# -------------------------
Write-Host "`n[3/4] GOLD: Final preprocessing..."
& $pythonExe ".\scripts\gold_mendeley_survival.py"

# -------------------------
# 4. SURVIVAL MODEL
# -------------------------
Write-Host "`n[4/4] SURVIVAL: CoxPH tuning + evaluation..."
& $pythonExe ".\scripts\survival_pipeline.py" `
    --data ".\out\gold\gold_survival.csv" `
    --out ".\out\survival" `
    --test_size 0.20 `
    --val_size 0.25 `
    --cv_folds 10 `
    --n_iter 25 `
    --seed 42

Write-Host "`n=== PIPELINE COMPLETE ==="
Write-Host "Outputs are under the 'out' folder."
