# DAAN 888 – Food Spoilage Survival Pipeline

This project implements a Bronze–Silver–Gold data pipeline plus a Cox proportional hazards survival model for Mendeley shelf-life sensor data.

## How to Run

1. Install Python 3.x.
2. Install dependencies:

   ```bash
   py -m pip install -r requirements.txt
   # or
   python -m pip install -r requirements.txt
