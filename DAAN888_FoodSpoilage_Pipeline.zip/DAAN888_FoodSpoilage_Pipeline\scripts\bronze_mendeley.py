# bronze_mendeley.py
"""
Create BRONZE layer for Mendeley Shelf-Life data.

"""

import shutil
from pathlib import Path

def main():
    # Project root = one level up from /scripts
    project_root = Path(__file__).resolve().parents[1]

    # 1. Path to the original raw file (inside project)
    raw_path = project_root / "data" / "raw" / "2.Mendeley_SensorFeed.csv"

    if not raw_path.exists():
        raise FileNotFoundError(f"Raw file not found: {raw_path}")

    # 2. Bronze output folder
    bronze_dir = project_root / "out" / "bronze"
    bronze_dir.mkdir(parents=True, exist_ok=True)

    # 3. Bronze file name
    bronze_path = bronze_dir / "Mendeley_SensorFeed_bronze.csv"

    # 4. Copy the raw file WITHOUT modification
    shutil.copy2(raw_path, bronze_path)

    print("=== BRONZE LAYER CREATED ===")
    print(f"Source (raw) : {raw_path}")
    print(f"Bronze copy  : {bronze_path}")

if __name__ == "__main__":
    main()
